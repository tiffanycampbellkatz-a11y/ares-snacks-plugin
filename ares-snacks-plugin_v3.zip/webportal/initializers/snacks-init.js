
export function initialize(application) {
  // No-op: Ares core templates can include <ProfileSnacks /> via plugin autoload.
  // This file ensures the component bundle is registered.
}
export default {
  initialize
};
